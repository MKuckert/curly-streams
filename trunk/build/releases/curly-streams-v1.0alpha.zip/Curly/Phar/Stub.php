<?php

echo 'Hello from Stub!';